import { LegalResearcher } from './agents/LegalResearcher.js';
import { ContractAnalyst } from './agents/ContractAnalyst.js';
import { LegalStrategist } from './agents/LegalStrategist.js';
import { TeamLead } from './agents/TeamLead.js';
import chalk from 'chalk';

// Initialize the legal team
const researcher = new LegalResearcher();
const analyst = new ContractAnalyst();
const strategist = new LegalStrategist();
const teamLead = new TeamLead(researcher, analyst, strategist);

// Example usage
async function demo() {
  console.log(chalk.blue('AI Legal Agent Team Demo'));
  console.log(chalk.yellow('\nAnalyzing Contract...'));
  
  const sampleContract = {
    type: 'Service Agreement',
    content: 'Sample contract content...'
  };

  const analysis = await teamLead.analyzeCase(sampleContract, 'contract');
  console.log(chalk.green('\nAnalysis Report:'));
  console.log(JSON.stringify(analysis, null, 2));
}

demo().catch(console.error);