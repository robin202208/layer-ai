import React, { useState } from 'react';
import { LegalResearcher } from './agents/LegalResearcher.js';
import { ContractAnalyst } from './agents/ContractAnalyst.js';
import { LegalStrategist } from './agents/LegalStrategist.js';
import { TeamLead } from './agents/TeamLead.js';
import { analyzeWithGPT } from './services/openai.js';

function App() {
  const [language, setLanguage] = useState('Chinese');
  const [documentType, setDocumentType] = useState('contract');
  const [documentContent, setDocumentContent] = useState('');
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const translations = {
    English: {
      title: 'AI Legal Analysis System',
      subtitle: 'Professional Legal Document Analysis Platform',
      documentType: 'Document Type',
      documentContent: 'Document Content',
      analyze: 'Analyze Document',
      analyzing: 'Analyzing...',
      results: 'Analysis Results',
      placeholder: 'Enter your document content here...',
      contract: 'Contract Analysis',
      regulation: 'Regulation Review',
      risk: 'Risk Assessment',
      compliance: 'Compliance Check',
      error: 'An error occurred during analysis',
      apiAnalysis: 'AI Deep Analysis',
      localAnalysis: 'Professional Analysis'
    },
    Chinese: {
      title: 'AI 法律分析系统',
      subtitle: '专业法律文件分析平台',
      documentType: '文档类型',
      documentContent: '文档内容',
      analyze: '开始分析',
      analyzing: '分析中...',
      results: '分析结果',
      placeholder: '请在此输入您的文档内容...',
      contract: '合同分析',
      regulation: '法规审查',
      risk: '风险评估',
      compliance: '合规检查',
      error: '分析过程中出现错误',
      apiAnalysis: 'AI 深度分析',
      localAnalysis: '专业解析'
    }
  };

  const t = translations[language];

  const handleAnalysis = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const researcher = new LegalResearcher();
      const analyst = new ContractAnalyst();
      const strategist = new LegalStrategist();
      const teamLead = new TeamLead(researcher, analyst, strategist);

      const document = {
        type: documentType,
        content: documentContent
      };

      const [gptAnalysis, localAnalysis] = await Promise.all([
        analyzeWithGPT(documentContent, language),
        teamLead.analyzeCase(document, documentType)
      ]);

      setAnalysis({
        localAnalysis: JSON.parse(JSON.stringify(localAnalysis)),
        gptAnalysis
      });
    } catch (error) {
      console.error('Analysis failed:', error);
      setError(t.error);
    }
    
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="max-w-6xl mx-auto px-4 py-12">
        {/* Header Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">{t.title}</h1>
          <p className="text-xl text-gray-600">{t.subtitle}</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Document Input Section */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
              {/* Language Selector */}
              <div className="flex justify-end mb-6">
                <select
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  className="px-4 py-2 border border-gray-200 rounded-lg bg-white text-gray-700 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="Chinese">中文</option>
                  <option value="English">English</option>
                </select>
              </div>

              {/* Document Type Selection */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                {['contract', 'regulation', 'risk', 'compliance'].map((type) => (
                  <button
                    key={type}
                    onClick={() => setDocumentType(type)}
                    className={`p-4 rounded-lg text-center transition-all ${
                      documentType === type
                        ? 'bg-blue-600 text-white shadow-md'
                        : 'bg-gray-50 text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    {t[type]}
                  </button>
                ))}
              </div>

              {/* Document Content Input */}
              <div className="mb-6">
                <textarea
                  value={documentContent}
                  onChange={(e) => setDocumentContent(e.target.value)}
                  className="w-full h-64 p-4 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                  placeholder={t.placeholder}
                />
              </div>

              {/* Analysis Button */}
              <button
                onClick={handleAnalysis}
                disabled={loading || !documentContent}
                className="w-full py-3 px-6 rounded-lg bg-gradient-to-r from-blue-600 to-blue-700 text-white font-medium hover:from-blue-700 hover:to-blue-800 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? t.analyzing : t.analyze}
              </button>

              {error && (
                <div className="mt-4 p-4 bg-red-50 text-red-700 rounded-lg border border-red-100">
                  {error}
                </div>
              )}
            </div>
          </div>

          {/* Analysis Results Section */}
          <div className="lg:col-span-1">
            {analysis && (
              <div className="bg-white rounded-xl shadow-lg p-8 space-y-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">{t.results}</h2>
                
                {/* AI Analysis */}
                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-lg">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">{t.apiAnalysis}</h3>
                  <div className="text-gray-700 whitespace-pre-wrap">
                    {analysis.gptAnalysis}
                  </div>
                </div>

                {/* Professional Analysis */}
                <div className="bg-gradient-to-r from-gray-50 to-gray-100 p-6 rounded-lg">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">{t.localAnalysis}</h3>
                  <pre className="text-gray-700 whitespace-pre-wrap text-sm">
                    {JSON.stringify(analysis.localAnalysis, null, 2)}
                  </pre>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;