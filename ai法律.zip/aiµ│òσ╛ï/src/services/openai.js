import axios from 'axios';

const OPENAI_API_URL = 'https://api.aihubmix.com/v1/chat/completions';

export async function analyzeWithGPT(content, language) {
  const apiKey = 'sk-JYlLDC7JhTcs9KbR49D639EeCe134169Bc081aEb9eF6751d';
  
  try {
    const response = await axios.post(
      OPENAI_API_URL,
      {
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: `You are a legal analysis expert. Analyze the following document and provide insights in ${language}.`
          },
          {
            role: "user",
            content: content
          }
        ],
        temperature: 0.7,
        max_tokens: 1000
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`
        }
      }
    );
    
    if (response.data && response.data.choices && response.data.choices[0]) {
      return response.data.choices[0].message.content;
    }
    
    throw new Error('Invalid API response format');
  } catch (error) {
    console.error('OpenAI API Error:', error.response?.data || error.message);
    
    const errorMessage = language === 'Chinese' 
      ? `API 调用失败: ${error.response?.data?.error?.message || error.message}`
      : `API call failed: ${error.response?.data?.error?.message || error.message}`;
    return errorMessage;
  }
}